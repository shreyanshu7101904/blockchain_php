<?php

?>
<html>
<head>
</head>
<body>
<h1>admin Login</h1>
<form action="logcode.php" method="post">
USERNAME <input type="text" name="username"/><br/>
PASSWORD <input type="password" name="pass"/><br/>
<input type="submit" value="login"/>
</form>
</body>
</html>